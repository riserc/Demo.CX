import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  // Skip middleware for API routes, static assets, and special pages
  if (
    request.nextUrl.pathname.startsWith("/api/") ||
    request.nextUrl.pathname.startsWith("/_next/") ||
    request.nextUrl.pathname.includes(".") ||
    request.nextUrl.pathname.startsWith("/login") ||
    request.nextUrl.pathname.startsWith("/force-auth") ||
    request.nextUrl.pathname.startsWith("/auth-check")
  ) {
    return NextResponse.next()
  }

  // Check if the user is authenticated from cookies
  const isAuthenticatedCookie = request.cookies.get("isAuthenticated")?.value === "true"

  // If authenticated by cookie, allow access
  if (isAuthenticatedCookie) {
    return NextResponse.next()
  }

  // If not authenticated, redirect to login
  return NextResponse.redirect(new URL("/login", request.url))
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico).*)"],
}
