"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

// This tells Next.js to always render this page on the client side
export const dynamic = "force-dynamic"

export default function ForceAuthPage() {
  const [isBrowser, setIsBrowser] = useState(false)
  const [status, setStatus] = useState("Initializing...")

  useEffect(() => {
    setIsBrowser(true)

    // Now we can safely run browser code
    forceAuth()
  }, [])

  const forceAuth = async () => {
    try {
      setStatus("Setting authentication data...")

      // Try localStorage
      try {
        localStorage.setItem("isAuthenticated", "true")
        localStorage.setItem("user", JSON.stringify({ email: "demo@example.com" }))
        setStatus((prev) => prev + "\nLocalStorage set successfully")
      } catch (error) {
        setStatus((prev) => prev + `\nLocalStorage error: ${error instanceof Error ? error.message : String(error)}`)
      }

      // Also set cookies
      try {
        document.cookie = `isAuthenticated=true; path=/; max-age=${7 * 24 * 60 * 60}`
        document.cookie = `userEmail=demo@example.com; path=/; max-age=${7 * 24 * 60 * 60}`
        setStatus((prev) => prev + "\nCookies set successfully")
      } catch (error) {
        setStatus((prev) => prev + `\nCookie error: ${error instanceof Error ? error.message : String(error)}`)
      }

      // Wait a moment
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setStatus((prev) => prev + "\nAuthentication complete. Redirecting...")

      // Redirect to home
      window.location.href = "/"
    } catch (error) {
      setStatus((prev) => prev + `\nError: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  const handleManualContinue = () => {
    if (isBrowser) {
      window.location.href = "/"
    }
  }

  // Initial loading state or server-side rendering
  if (!isBrowser) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-100 dark:bg-gray-900 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Authentication Override</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-40 flex items-center justify-center">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-teal-500 border-t-transparent"></div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Client-side rendering
  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-100 dark:bg-gray-900 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Authentication Override</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded text-xs font-mono w-full overflow-auto max-h-40">
              <pre>{status}</pre>
            </div>

            <div className="flex flex-col gap-2">
              <Button onClick={handleManualContinue}>Continue to Dashboard</Button>

              <div className="flex gap-2 justify-center mt-4">
                <a href="/" className="text-sm text-blue-500 underline">
                  Home
                </a>
                <a href="/dashboard" className="text-sm text-blue-500 underline">
                  Dashboard
                </a>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
