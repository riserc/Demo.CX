"use client"

import { useEffect, useState } from "react"
import { useParams, notFound, useRouter } from "next/navigation"
import { createClientClient } from "@/lib/supabase/client"
import { isSafeId } from "@/lib/utils"
import CallSummary from "@/components/call-summary"
import SentimentAnalysis from "@/components/sentiment-analysis"
import AgentPerformance from "@/components/agent-performance"
import KeyInsights from "@/components/key-insights"
import CallTranscript from "@/components/call-transcript"
import ActionButtons from "@/components/action-buttons"
import EngagementHeatmap from "@/components/engagement-heatmap"
import { toast } from "@/components/ui/use-toast"

export default function CallDashboard() {
  const params = useParams()
  const callId = params.id as string
  const [call, setCall] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const supabase = createClientClient()

  useEffect(() => {
    const fetchCall = async () => {
      try {
        // Validate the ID format
        if (!isSafeId(callId)) {
          toast({
            title: "Invalid Call ID",
            description: "The call ID format is invalid.",
            variant: "destructive",
          })
          router.push("/")
          return
        }

        // Check if this is a demo call
        if (callId.startsWith("demo-")) {
          const demoCalls = JSON.parse(localStorage.getItem("demoCalls") || "[]")
          const demoCall = demoCalls.find((c: any) => c.id === callId)

          if (demoCall) {
            setCall(demoCall)
          } else {
            notFound()
          }
        } else {
          // Try to fetch from Supabase
          const { data, error } = await supabase.from("calls").select("*").eq("id", callId).single()

          if (error || !data) {
            console.error("Error fetching call:", error)
            notFound()
          }

          setCall(data)
        }
      } catch (error) {
        console.error("Error fetching call:", error)
        notFound()
      } finally {
        setIsLoading(false)
      }
    }

    fetchCall()
  }, [callId, supabase, router])

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div className="h-8 w-48 bg-gray-100 dark:bg-gray-800 animate-pulse rounded-md" />
          <div className="h-8 w-32 bg-gray-100 dark:bg-gray-800 animate-pulse rounded-md" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="h-64 bg-gray-100 dark:bg-gray-800 animate-pulse rounded-md" />
          <div className="h-64 bg-gray-100 dark:bg-gray-800 animate-pulse rounded-md" />
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Call Analysis</h1>
        <ActionButtons callId={callId} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <CallSummary call={call} />
        <SentimentAnalysis callId={callId} />
      </div>

      <EngagementHeatmap callId={callId} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <AgentPerformance callId={callId} />
        <KeyInsights callId={callId} />
        <CallTranscript callId={callId} />
      </div>
    </div>
  )
}
