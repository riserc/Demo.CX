"use client"

import { useEffect, useState } from "react"
import UploadSection from "@/components/upload-section"
import RecentAnalytics from "@/components/recent-analytics"

export default function Home() {
  const [isSettingUp, setIsSettingUp] = useState(true)

  useEffect(() => {
    // Call the setup API to ensure database tables exist
    const setupDb = async () => {
      try {
        await fetch("/api/setup-db")
      } catch (error) {
        console.error("Error setting up database:", error)
      } finally {
        setIsSettingUp(false)
      }
    }

    setupDb()
  }, [])

  return (
    <div className="space-y-8">
      <UploadSection />
      <RecentAnalytics />
    </div>
  )
}
