import { createServerClient } from "@/lib/supabase/server"
import ReportsList from "@/components/reports-list"
import GenerateReportForm from "@/components/generate-report-form"

export default async function ReportsPage() {
  const supabase = createServerClient()

  // Fetch reports
  const { data: reports } = await supabase.from("reports").select("*").order("created_at", { ascending: false })

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Reports</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <GenerateReportForm />
        </div>
        <div className="md:col-span-2">
          <ReportsList reports={reports || []} />
        </div>
      </div>
    </div>
  )
}
