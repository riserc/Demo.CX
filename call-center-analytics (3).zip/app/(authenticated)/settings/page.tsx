import EmailSettings from "@/components/email-settings"
import ApiSettings from "@/components/api-settings"

export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Settings</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <EmailSettings />
        <ApiSettings />
      </div>
    </div>
  )
}
