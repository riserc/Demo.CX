"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

// This tells Next.js to always render this page on the client side
export const dynamic = "force-dynamic"

export default function AuthCheckPage() {
  // Use a state to track if we're in the browser
  const [isBrowser, setIsBrowser] = useState(false)

  // State for auth status - initialized with empty values
  const [authStatus, setAuthStatus] = useState({
    localStorage: { isAuthenticated: false, user: null, error: null },
    cookies: { isAuthenticated: false, userEmail: null, error: null },
    allCookies: "",
  })

  // Only run once when component mounts on client
  useEffect(() => {
    setIsBrowser(true)

    // Now we can safely check auth status
    checkAuthStatus()
  }, [])

  // Separate function to check auth status
  const checkAuthStatus = () => {
    try {
      // Check localStorage
      let localStorageAuth = false
      let localStorageUser = null
      let localStorageError = null

      try {
        localStorageAuth = localStorage.getItem("isAuthenticated") === "true"
        const userStr = localStorage.getItem("user")
        if (userStr) {
          localStorageUser = JSON.parse(userStr)
        }
      } catch (error) {
        localStorageError = `Error: ${error instanceof Error ? error.message : String(error)}`
      }

      // Check cookies
      let cookieAuth = false
      let cookieUserEmail = null
      let cookieError = null
      let allCookiesStr = ""

      try {
        // Get all cookies
        allCookiesStr = document.cookie || "No cookies"

        // Parse cookies
        const cookies = document.cookie.split(";")

        // Check for isAuthenticated cookie
        const authCookie = cookies.find((c) => c.trim().startsWith("isAuthenticated="))
        if (authCookie) {
          cookieAuth = authCookie.split("=")[1] === "true"
        }

        // Check for userEmail cookie
        const emailCookie = cookies.find((c) => c.trim().startsWith("userEmail="))
        if (emailCookie) {
          cookieUserEmail = emailCookie.split("=")[1]
        }
      } catch (error) {
        cookieError = `Error: ${error instanceof Error ? error.message : String(error)}`
      }

      // Update state with all the values
      setAuthStatus({
        localStorage: {
          isAuthenticated: localStorageAuth,
          user: localStorageUser,
          error: localStorageError,
        },
        cookies: {
          isAuthenticated: cookieAuth,
          userEmail: cookieUserEmail,
          error: cookieError,
        },
        allCookies: allCookiesStr,
      })
    } catch (error) {
      console.error("Error checking auth status:", error)
    }
  }

  const handleSetAuth = () => {
    if (!isBrowser) return

    try {
      // Set localStorage
      localStorage.setItem("isAuthenticated", "true")
      localStorage.setItem("user", JSON.stringify({ email: "demo@example.com" }))

      // Set cookies
      document.cookie = `isAuthenticated=true; path=/; max-age=${7 * 24 * 60 * 60}`
      document.cookie = `userEmail=demo@example.com; path=/; max-age=${7 * 24 * 60 * 60}`

      // Refresh the page
      window.location.reload()
    } catch (error) {
      alert("Error setting auth: " + (error instanceof Error ? error.message : String(error)))
    }
  }

  const handleClearAuth = () => {
    if (!isBrowser) return

    try {
      // Clear localStorage
      localStorage.removeItem("isAuthenticated")
      localStorage.removeItem("user")

      // Clear cookies
      document.cookie = "isAuthenticated=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;"
      document.cookie = "userEmail=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;"

      // Refresh the page
      window.location.reload()
    } catch (error) {
      alert("Error clearing auth: " + (error instanceof Error ? error.message : String(error)))
    }
  }

  const handleGoHome = () => {
    if (!isBrowser) return
    window.location.href = "/"
  }

  // Initial loading state or server-side rendering
  if (!isBrowser) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-100 dark:bg-gray-900 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Authentication Status</CardTitle>
            <CardDescription>Loading authentication status...</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-40 flex items-center justify-center">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-teal-500 border-t-transparent"></div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Client-side rendering with auth data
  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-100 dark:bg-gray-900 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Authentication Status</CardTitle>
          <CardDescription>Check if you're authenticated</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded">
              <h3 className="font-bold mb-2">LocalStorage:</h3>
              <div>
                <strong>Is Authenticated:</strong> {authStatus.localStorage.isAuthenticated ? "Yes" : "No"}
              </div>
              {authStatus.localStorage.user && (
                <div>
                  <strong>User:</strong> <pre>{JSON.stringify(authStatus.localStorage.user, null, 2)}</pre>
                </div>
              )}
              {authStatus.localStorage.error && (
                <div className="text-red-500">
                  <strong>Error:</strong> {authStatus.localStorage.error}
                </div>
              )}
            </div>

            <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded">
              <h3 className="font-bold mb-2">Cookies:</h3>
              <div>
                <strong>Is Authenticated:</strong> {authStatus.cookies.isAuthenticated ? "Yes" : "No"}
              </div>
              {authStatus.cookies.userEmail && (
                <div>
                  <strong>User Email:</strong> {authStatus.cookies.userEmail}
                </div>
              )}
              {authStatus.cookies.error && (
                <div className="text-red-500">
                  <strong>Error:</strong> {authStatus.cookies.error}
                </div>
              )}
            </div>

            <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded">
              <h3 className="font-bold mb-2">All Cookies:</h3>
              <pre className="text-xs overflow-auto max-h-20">{authStatus.allCookies}</pre>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col gap-2">
          <div className="flex gap-2 w-full">
            <Button onClick={handleSetAuth} className="flex-1">
              Set Auth
            </Button>
            <Button variant="destructive" onClick={handleClearAuth} className="flex-1">
              Clear Auth
            </Button>
          </div>
          <Button onClick={handleGoHome} variant="outline" className="w-full">
            Go to Home
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
