import { createServerClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const supabase = createServerClient()

    // Try to create the calls table if it doesn't exist
    try {
      // Check if the table exists
      const { error: checkError } = await supabase.from("calls").select("id").limit(1)

      if (checkError) {
        // If there's an error, try to create the table
        await supabase.rpc("create_calls_table").catch(async () => {
          console.log("RPC not available, using raw SQL")
          // Fallback to direct SQL if RPC is not available
          await supabase.from("calls").insert({
            id: "00000000-0000-0000-0000-000000000000",
            file_name: "system-init",
            file_path: "system-init",
            file_url: "system-init",
            status: "system",
            analysis_result: {},
            created_at: new Date().toISOString(),
          })
        })
      }
    } catch (error) {
      console.error("Error with calls table:", error)
    }

    // Try to create the reports table if it doesn't exist
    try {
      // Check if the table exists
      const { error: checkError } = await supabase.from("reports").select("id").limit(1)

      if (checkError) {
        // If there's an error, try to create the table
        await supabase.rpc("create_reports_table").catch(async () => {
          console.log("RPC not available, using raw SQL")
          // Fallback to direct SQL if RPC is not available
          await supabase.from("reports").insert({
            id: "00000000-0000-0000-0000-000000000000",
            call_id: "00000000-0000-0000-0000-000000000000",
            email: "system@example.com",
            pdf_url: "system-init",
            status: "system",
            created_at: new Date().toISOString(),
          })
        })
      }
    } catch (error) {
      console.error("Error with reports table:", error)
    }

    return NextResponse.json({ success: true, message: "Database setup complete" })
  } catch (error) {
    console.error("Error setting up database:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to set up database, but the app will work in demo mode",
        message: "The application will continue to work in demo mode with local storage",
      },
      { status: 200 },
    ) // Return 200 even on error to allow the app to continue
  }
}
