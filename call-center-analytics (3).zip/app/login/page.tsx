"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Upload } from "lucide-react"

// This tells Next.js to always render this page on the client side
export const dynamic = "force-dynamic"

export default function LoginPage() {
  const [isBrowser, setIsBrowser] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [debugInfo, setDebugInfo] = useState<string>("")
  const [loginAttempts, setLoginAttempts] = useState(0)

  useEffect(() => {
    setIsBrowser(true)

    // Now we can safely check if already logged in
    checkIfLoggedIn()
  }, [])

  const checkIfLoggedIn = () => {
    try {
      // Try to get auth status from localStorage
      const isAuth = localStorage.getItem("isAuthenticated") === "true"

      if (isAuth) {
        setDebugInfo("Already authenticated, redirecting...")
        // Use the most direct method to navigate
        window.location.href = "/"
      }
    } catch (error) {
      setDebugInfo(`Error checking auth: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  const handleLogin = async () => {
    if (!isBrowser) return

    setIsLoading(true)
    setLoginAttempts((prev) => prev + 1)

    try {
      setDebugInfo("Login attempt started...")

      // Try to set authentication in localStorage
      try {
        localStorage.setItem("isAuthenticated", "true")
        localStorage.setItem("user", JSON.stringify({ email: "demo@example.com" }))
        setDebugInfo((prev) => prev + "\nLocalStorage set successfully")
      } catch (error) {
        setDebugInfo((prev) => prev + `\nLocalStorage error: ${error instanceof Error ? error.message : String(error)}`)
      }

      // Also set a cookie as backup
      try {
        document.cookie = `isAuthenticated=true; path=/; max-age=${7 * 24 * 60 * 60}`
        document.cookie = `userEmail=demo@example.com; path=/; max-age=${7 * 24 * 60 * 60}`
        setDebugInfo((prev) => prev + "\nCookies set successfully")
      } catch (error) {
        setDebugInfo((prev) => prev + `\nCookie error: ${error instanceof Error ? error.message : String(error)}`)
      }

      // Wait a moment to ensure storage is set
      await new Promise((resolve) => setTimeout(resolve, 500))

      setDebugInfo((prev) => prev + "\nRedirecting to home page...")

      // Use the most direct method to navigate
      window.location.href = "/"
    } catch (error) {
      setDebugInfo((prev) => prev + `\nLogin error: ${error instanceof Error ? error.message : String(error)}`)
    } finally {
      setIsLoading(false)
    }
  }

  // Force login after 3 attempts
  useEffect(() => {
    if (!isBrowser) return

    if (loginAttempts >= 3) {
      setDebugInfo((prev) => prev + "\nMultiple login attempts detected, trying force navigation...")
      window.location.replace("/force-auth")
    }
  }, [loginAttempts, isBrowser])

  // Initial loading state or server-side rendering
  if (!isBrowser) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-100 dark:bg-gray-900 p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="space-y-1 text-center">
            <div className="flex justify-center mb-2">
              <Upload className="h-10 w-10 text-teal-500" />
            </div>
            <CardTitle className="text-2xl font-bold">Vaaɹi.Cx</CardTitle>
            <CardDescription>Demo Call Analytics Platform</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center">
            <p className="mb-6 text-center text-sm text-gray-600 dark:text-gray-400">Loading...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Client-side rendering
  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-100 dark:bg-gray-900 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-center mb-2">
            <Upload className="h-10 w-10 text-teal-500" />
          </div>
          <CardTitle className="text-2xl font-bold">Vaaɹi.Cx</CardTitle>
          <CardDescription>Demo Call Analytics Platform</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center">
          <p className="mb-6 text-center text-sm text-gray-600 dark:text-gray-400">
            This is a demo application. Click the button below to enter.
          </p>
          <Button onClick={handleLogin} className="w-full max-w-xs" disabled={isLoading}>
            {isLoading ? "Logging in..." : "Enter Demo"}
          </Button>

          {/* Direct links as fallback */}
          <div className="mt-4">
            <p className="text-sm text-gray-500 mb-2">If the button doesn't work, try these direct links:</p>
            <div className="flex gap-2 justify-center">
              <a href="/" className="text-sm text-blue-500 underline">
                Home
              </a>
              <a href="/dashboard" className="text-sm text-blue-500 underline">
                Dashboard
              </a>
              <a href="/force-auth" className="text-sm text-blue-500 underline">
                Force Auth
              </a>
            </div>
          </div>

          {/* Debug info */}
          {debugInfo && (
            <div className="mt-4 p-2 bg-gray-100 dark:bg-gray-800 rounded text-xs font-mono w-full overflow-auto max-h-40">
              <pre>{debugInfo}</pre>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-center">
          <p className="text-sm text-gray-500 dark:text-gray-400">No password required - automatic authentication</p>
        </CardFooter>
      </Card>
    </div>
  )
}
