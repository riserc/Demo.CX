"use client"

import { useEffect, useState } from "react"
import { createClientClient } from "@/lib/supabase/client"
import { isSafeId } from "@/lib/utils"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

type AgentPerformanceProps = {
  callId: string
}

export default function AgentPerformance({ callId }: AgentPerformanceProps) {
  const [performanceData, setPerformanceData] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const supabase = createClientClient()

  useEffect(() => {
    const fetchPerformanceData = async () => {
      try {
        // Validate the ID format
        if (!isSafeId(callId)) {
          // Generate mock data for invalid IDs
          const mockData = generateMockData()
          setPerformanceData(mockData)
          setIsLoading(false)
          return
        }

        // Check if this is a demo call
        if (callId.startsWith("demo-")) {
          const demoCalls = JSON.parse(localStorage.getItem("demoCalls") || "[]")
          const demoCall = demoCalls.find((c: any) => c.id === callId)

          if (demoCall?.analysis_result?.agent_metrics) {
            setPerformanceData(demoCall.analysis_result.agent_metrics)
          } else {
            // Generate mock data if not available
            const mockData = generateMockData()
            setPerformanceData(mockData)
          }
        } else {
          // Try to fetch from Supabase
          const { data: call, error } = await supabase.from("calls").select("analysis_result").eq("id", callId).single()

          if (error) throw error

          if (call?.analysis_result?.agent_metrics) {
            setPerformanceData(call.analysis_result.agent_metrics)
          } else {
            // Generate mock data if not available
            const mockData = generateMockData()
            setPerformanceData(mockData)
          }
        }
      } catch (error) {
        console.error("Error fetching performance data:", error)
        // Generate mock data on error
        const mockData = generateMockData()
        setPerformanceData(mockData)
      } finally {
        setIsLoading(false)
      }
    }

    fetchPerformanceData()
  }, [callId, supabase])

  const generateMockData = () => {
    return [
      { metric: "Empathy", score: Math.random() * 100 },
      { metric: "Clarity", score: Math.random() * 100 },
      { metric: "Resolution", score: Math.random() * 100 },
      { metric: "Knowledge", score: Math.random() * 100 },
      { metric: "Professionalism", score: Math.random() * 100 },
    ]
  }

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Agent Performance</CardTitle>
          <CardDescription>Key performance metrics</CardDescription>
        </CardHeader>
        <CardContent className="h-80">
          <div className="h-full w-full bg-gray-100 dark:bg-gray-800 animate-pulse rounded-md" />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Agent Performance</CardTitle>
        <CardDescription>Key performance metrics</CardDescription>
      </CardHeader>
      <CardContent className="h-80">
        <ChartContainer
          config={{
            score: {
              label: "Score",
              color: "hsl(var(--chart-3))",
            },
          }}
          className="h-full"
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={performanceData} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <XAxis type="number" domain={[0, 100]} />
              <YAxis dataKey="metric" type="category" width={100} />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar dataKey="score" fill="var(--color-score)" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
