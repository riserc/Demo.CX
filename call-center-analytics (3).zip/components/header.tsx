"use client"

import { useState, useEffect } from "react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Bell, LogOut, Menu, Moon, Search, Sun, User } from "lucide-react"
import TopNavigation from "./top-navigation"

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [userEmail, setUserEmail] = useState<string | null>("demo@example.com")
  const { setTheme } = useTheme()

  useEffect(() => {
    // Only run in browser
    if (typeof window === "undefined") return

    // Get user info from localStorage or cookie
    try {
      // Try localStorage first
      const userStr = localStorage.getItem("user")
      if (userStr) {
        const user = JSON.parse(userStr)
        setUserEmail(user.email)
        return
      }

      // Fall back to cookie
      if (typeof document !== "undefined") {
        const cookies = document.cookie.split(";")
        const userEmailCookie = cookies.find((cookie) => cookie.trim().startsWith("userEmail="))
        if (userEmailCookie) {
          const email = userEmailCookie.split("=")[1]
          setUserEmail(email)
        }
      }
    } catch (e) {
      console.error("Error getting user data:", e)
    }
  }, [])

  // Function to delete a cookie
  const deleteCookie = (name: string) => {
    if (typeof document === "undefined") return
    document.cookie = name + "=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;"
  }

  const handleLogout = () => {
    try {
      // Clear localStorage
      localStorage.removeItem("isAuthenticated")
      localStorage.removeItem("user")

      // Clear cookies
      deleteCookie("isAuthenticated")
      deleteCookie("userEmail")

      // Redirect to login
      window.location.href = "/login"
    } catch (error) {
      console.error("Logout failed:", error)
      // If there's an error, still try to redirect
      window.location.href = "/login"
    }
  }

  return (
    <header className="bg-white dark:bg-gray-900 border-b">
      <div className="flex flex-col px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex md:hidden">
            <Button variant="ghost" size="icon" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
              <Menu className="h-5 w-5" />
              <span className="sr-only">Open menu</span>
            </Button>
          </div>

          <div className="flex-1 flex justify-center px-2 lg:ml-6 lg:justify-end">
            <div className="max-w-lg w-full lg:max-w-xs">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" aria-hidden="true" />
                </div>
                <Input type="search" placeholder="Search calls..." className="pl-10" />
              </div>
            </div>
          </div>

          <div className="flex items-center">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Bell className="h-5 w-5" />
                  <span className="sr-only">Notifications</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>New call analyzed</DropdownMenuItem>
                <DropdownMenuItem>Report generated</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  {/* Toggle between sun and moon based on theme */}
                  <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                  <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
                  <span className="sr-only">Toggle theme</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setTheme("light")}>Light</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setTheme("dark")}>Dark</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setTheme("system")}>System</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="ml-2">
                  <User className="h-5 w-5" />
                  <span className="sr-only">User menu</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem disabled>{userEmail || "Demo User"}</DropdownMenuItem>
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="h-4 w-4 mr-2" />
                  Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Add the top navigation */}
        <div className="py-2 border-t">
          <TopNavigation />
        </div>

        {/* Mobile menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-2 border-t">
            <TopNavigation />
          </div>
        )}
      </div>
    </header>
  )
}
