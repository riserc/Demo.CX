"use client"

import { useEffect, useState } from "react"
import { createClientClient } from "@/lib/supabase/client"
import { isSafeId } from "@/lib/utils"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"

type CallTranscriptProps = {
  callId: string
}

type TranscriptEntry = {
  speaker: "agent" | "customer"
  text: string
  time: string
}

export default function CallTranscript({ callId }: CallTranscriptProps) {
  const [transcript, setTranscript] = useState<TranscriptEntry[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const supabase = createClientClient()

  useEffect(() => {
    const fetchTranscript = async () => {
      try {
        // Validate the ID format
        if (!isSafeId(callId)) {
          // Generate mock data for invalid IDs
          const mockData = generateMockData()
          setTranscript(mockData)
          setIsLoading(false)
          return
        }

        // Check if this is a demo call
        if (callId.startsWith("demo-")) {
          const demoCalls = JSON.parse(localStorage.getItem("demoCalls") || "[]")
          const demoCall = demoCalls.find((c: any) => c.id === callId)

          if (demoCall?.analysis_result?.transcript) {
            setTranscript(demoCall.analysis_result.transcript)
          } else {
            // Generate mock data if not available
            const mockData = generateMockData()
            setTranscript(mockData)
          }
        } else {
          // Try to fetch from Supabase
          const { data: call, error } = await supabase.from("calls").select("analysis_result").eq("id", callId).single()

          if (error) throw error

          if (call?.analysis_result?.transcript) {
            setTranscript(call.analysis_result.transcript)
          } else {
            // Generate mock data if not available
            const mockData = generateMockData()
            setTranscript(mockData)
          }
        }
      } catch (error) {
        console.error("Error fetching transcript:", error)
        // Generate mock data on error
        const mockData = generateMockData()
        setTranscript(mockData)
      } finally {
        setIsLoading(false)
      }
    }

    fetchTranscript()
  }, [callId, supabase])

  const generateMockData = (): TranscriptEntry[] => {
    return [
      {
        speaker: "agent",
        text: "Thank you for calling customer support. How may I help you today?",
        time: "00:00",
      },
      {
        speaker: "customer",
        text: "Hi, I'm having trouble with my account. I can't seem to log in.",
        time: "00:05",
      },
      {
        speaker: "agent",
        text: "I'm sorry to hear that. Let me help you with that. Can you please provide your account email?",
        time: "00:12",
      },
      {
        speaker: "customer",
        text: "Sure, it's customer@example.com",
        time: "00:18",
      },
      {
        speaker: "agent",
        text: "Thank you. I'm checking your account now. It looks like there might have been some suspicious activity and your account was temporarily locked for security reasons.",
        time: "00:25",
      },
      {
        speaker: "customer",
        text: "Oh, I see. How can I unlock it?",
        time: "00:40",
      },
      {
        speaker: "agent",
        text: "I can help you with that right now. I'll send a password reset link to your email. Once you reset your password, your account will be unlocked.",
        time: "00:45",
      },
      {
        speaker: "customer",
        text: "That sounds good. Thank you.",
        time: "01:00",
      },
      {
        speaker: "agent",
        text: "You're welcome. Is there anything else I can help you with today?",
        time: "01:05",
      },
      {
        speaker: "customer",
        text: "No, that's all. Thanks for your help.",
        time: "01:10",
      },
      {
        speaker: "agent",
        text: "You're welcome. Thank you for calling customer support. Have a great day!",
        time: "01:15",
      },
    ]
  }

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Call Transcript</CardTitle>
          <CardDescription>Full conversation transcript</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-16 bg-gray-100 dark:bg-gray-800 animate-pulse rounded-md" />
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Call Transcript</CardTitle>
        <CardDescription>Full conversation transcript</CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-80 pr-4">
          <div className="space-y-4">
            {transcript.map((entry, index) => (
              <div key={index} className="flex gap-3">
                <Avatar className="h-8 w-8">
                  <AvatarFallback
                    className={entry.speaker === "agent" ? "bg-teal-100 text-teal-600" : "bg-blue-100 text-blue-600"}
                  >
                    {entry.speaker === "agent" ? "A" : "C"}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex justify-between items-baseline">
                    <p className="text-sm font-medium">{entry.speaker === "agent" ? "Agent" : "Customer"}</p>
                    <span className="text-xs text-gray-500">{entry.time}</span>
                  </div>
                  <p className="text-sm mt-1">{entry.text}</p>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
