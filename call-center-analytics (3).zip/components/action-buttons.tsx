"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClientClient } from "@/lib/supabase/client"
import { isSafeId } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"
import { Download, FileText, Mail, Printer } from "lucide-react"
import { generatePdf } from "@/lib/generate-pdf"

type ActionButtonsProps = {
  callId: string
}

export default function ActionButtons({ callId }: ActionButtonsProps) {
  const [isEmailDialogOpen, setIsEmailDialogOpen] = useState(false)
  const [email, setEmail] = useState("")
  const [emailSubject, setEmailSubject] = useState("Call Analysis Report")
  const [emailMessage, setEmailMessage] = useState("Please find attached the call analysis report.")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const supabase = createClientClient()

  // Validate if this is a demo ID or a valid UUID
  const isDemo = callId.startsWith("demo-")
  const isValidId = isSafeId(callId)

  const handleDownloadPdf = async () => {
    if (!isValidId) {
      toast({
        title: "Invalid Call ID",
        description: "Cannot generate PDF for this call.",
        variant: "destructive",
      })
      return
    }

    try {
      setIsLoading(true)

      if (isDemo) {
        // For demo, just simulate a download
        const demoUrl = `https://example.com/demo-pdf-${Date.now()}.pdf`

        // Create a link and trigger download (this won't actually download anything in demo mode)
        const link = document.createElement("a")
        link.href = demoUrl
        link.download = `call-analysis-${callId}.pdf`
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)

        toast({
          title: "Demo PDF",
          description: "In a real app, this would download a PDF report.",
        })
        return
      }

      // Fetch call data
      const { data: call, error } = await supabase.from("calls").select("*").eq("id", callId).single()

      if (error) throw error

      // Generate PDF
      const pdfUrl = await generatePdf(call)

      // Create a link and trigger download
      const link = document.createElement("a")
      link.href = pdfUrl
      link.download = `call-analysis-${callId}.pdf`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)

      toast({
        title: "PDF Downloaded",
        description: "Your call analysis report has been downloaded.",
      })
    } catch (error) {
      console.error("Error downloading PDF:", error)
      toast({
        title: "Download Failed",
        description: "There was an error downloading the PDF report.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handlePrint = () => {
    window.print()
  }

  const handleSendEmail = async () => {
    if (!isValidId) {
      toast({
        title: "Invalid Call ID",
        description: "Cannot send email for this call.",
        variant: "destructive",
      })
      return
    }

    try {
      setIsLoading(true)

      // Validate email
      if (!email || !/\S+@\S+\.\S+/.test(email)) {
        throw new Error("Please enter a valid email address")
      }

      if (isDemo) {
        // For demo, just simulate sending an email
        await new Promise((resolve) => setTimeout(resolve, 1000))

        toast({
          title: "Demo Email Sent",
          description: `In a real app, this would send an email to ${email}.`,
        })

        setIsEmailDialogOpen(false)
        setEmail("")
        return
      }

      // Fetch call data
      const { data: call, error } = await supabase.from("calls").select("*").eq("id", callId).single()

      if (error) throw error

      // Generate PDF
      const pdfUrl = await generatePdf(call)

      // Create report record
      const { error: reportError } = await supabase.from("reports").insert({
        call_id: callId,
        email: email,
        pdf_url: pdfUrl,
        status: "sent",
        subject: emailSubject,
        message: emailMessage,
      })

      if (reportError) throw reportError

      toast({
        title: "Email Sent",
        description: `The report has been sent to ${email}.`,
      })

      setIsEmailDialogOpen(false)
      setEmail("")
    } catch (error: any) {
      console.error("Error sending email:", error)
      toast({
        title: "Email Failed",
        description: error.message || "There was an error sending the email.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <>
      <div className="flex gap-2">
        <Button variant="outline" size="sm" onClick={handleDownloadPdf} disabled={isLoading}>
          <Download className="h-4 w-4 mr-2" />
          Download PDF
        </Button>
        <Button variant="outline" size="sm" onClick={handlePrint} disabled={isLoading}>
          <Printer className="h-4 w-4 mr-2" />
          Print
        </Button>
        <Button variant="outline" size="sm" onClick={() => setIsEmailDialogOpen(true)} disabled={isLoading}>
          <Mail className="h-4 w-4 mr-2" />
          Email Report
        </Button>
        <Button variant="primary" size="sm" onClick={handleDownloadPdf} disabled={isLoading}>
          <FileText className="h-4 w-4 mr-2" />
          Analytics Report
        </Button>
      </div>

      <Dialog open={isEmailDialogOpen} onOpenChange={setIsEmailDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Email Report</DialogTitle>
            <DialogDescription>Send the call analysis report to an email address.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="email">Email address</Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="subject">Subject</Label>
              <Input id="subject" type="text" value={emailSubject} onChange={(e) => setEmailSubject(e.target.value)} />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="message">Message</Label>
              <Textarea id="message" rows={3} value={emailMessage} onChange={(e) => setEmailMessage(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEmailDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSendEmail} disabled={isLoading}>
              {isLoading ? "Sending..." : "Send Report"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
