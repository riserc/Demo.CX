"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClientClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"
import { generatePdf } from "@/lib/generate-pdf"

export default function GenerateReportForm() {
  const [email, setEmail] = useState("")
  const [callId, setCallId] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [calls, setCalls] = useState<any[]>([])
  const router = useRouter()
  const supabase = createClientClient()

  useState(() => {
    const fetchCalls = async () => {
      try {
        const { data, error } = await supabase
          .from("calls")
          .select("id, file_name")
          .order("created_at", { ascending: false })
          .limit(10)

        if (error) throw error
        setCalls(data || [])
      } catch (error) {
        console.error("Error fetching calls:", error)
      }
    }

    fetchCalls()
  })

  const handleGenerateReport = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      setIsLoading(true)

      // Validate inputs
      if (!callId) {
        throw new Error("Please select a call")
      }

      if (email && !/\S+@\S+\.\S+/.test(email)) {
        throw new Error("Please enter a valid email address")
      }

      // Fetch call data
      const { data: call, error } = await supabase.from("calls").select("*").eq("id", callId).single()

      if (error) throw error

      // Generate PDF
      const pdfUrl = await generatePdf(call)

      // Create report record
      const { data: report, error: reportError } = await supabase
        .from("reports")
        .insert({
          call_id: callId,
          email: email || null,
          pdf_url: pdfUrl,
          status: email ? "sent" : "generated",
        })
        .select()
        .single()

      if (reportError) throw reportError

      toast({
        title: "Report Generated",
        description: email ? `The report has been sent to ${email}.` : "The report has been generated successfully.",
      })

      // Reset form
      setEmail("")
      setCallId("")

      // Refresh the page to show the new report
      router.refresh()
    } catch (error: any) {
      console.error("Error generating report:", error)
      toast({
        title: "Generation Failed",
        description: error.message || "There was an error generating the report.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Generate Report</CardTitle>
        <CardDescription>Create and share call analysis reports</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleGenerateReport} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="call">Select Call</Label>
            <Select value={callId} onValueChange={setCallId}>
              <SelectTrigger id="call">
                <SelectValue placeholder="Select a call" />
              </SelectTrigger>
              <SelectContent>
                {calls.map((call) => (
                  <SelectItem key={call.id} value={call.id}>
                    {call.file_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email (Optional)</Label>
            <Input
              id="email"
              type="email"
              placeholder="Enter email to send report"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <p className="text-xs text-gray-500 dark:text-gray-400">Leave blank to generate without sending</p>
          </div>

          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? "Generating..." : "Generate Report"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
