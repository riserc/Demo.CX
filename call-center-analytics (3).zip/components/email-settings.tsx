"use client"

import type React from "react"

import { useState } from "react"
import { createClientClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { toast } from "@/components/ui/use-toast"

export default function EmailSettings() {
  const [defaultEmail, setDefaultEmail] = useState("")
  const [ccEmail, setCcEmail] = useState("")
  const [autoSendReports, setAutoSendReports] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const supabase = createClientClient()

  // Load settings from database
  useState(() => {
    const fetchSettings = async () => {
      try {
        const { data, error } = await supabase.from("settings").select("*").eq("type", "email").single()

        if (error && error.code !== "PGRST116") throw error

        if (data) {
          setDefaultEmail(data.settings.default_email || "")
          setCcEmail(data.settings.cc_email || "")
          setAutoSendReports(data.settings.auto_send_reports || false)
        }
      } catch (error) {
        console.error("Error fetching email settings:", error)
      }
    }

    fetchSettings()
  })

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      setIsLoading(true)

      // Validate emails
      if (defaultEmail && !/\S+@\S+\.\S+/.test(defaultEmail)) {
        throw new Error("Please enter a valid default email address")
      }

      if (ccEmail && !/\S+@\S+\.\S+/.test(ccEmail)) {
        throw new Error("Please enter a valid CC email address")
      }

      // Save settings
      const { error } = await supabase.from("settings").upsert({
        type: "email",
        settings: {
          default_email: defaultEmail,
          cc_email: ccEmail,
          auto_send_reports: autoSendReports,
        },
      })

      if (error) throw error

      toast({
        title: "Settings Saved",
        description: "Your email settings have been saved successfully.",
      })
    } catch (error: any) {
      console.error("Error saving email settings:", error)
      toast({
        title: "Save Failed",
        description: error.message || "There was an error saving your settings.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Email Settings</CardTitle>
        <CardDescription>Configure email preferences for reports</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSaveSettings} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="default-email">Default Email</Label>
            <Input
              id="default-email"
              type="email"
              placeholder="Enter default email for reports"
              value={defaultEmail}
              onChange={(e) => setDefaultEmail(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="cc-email">CC Email</Label>
            <Input
              id="cc-email"
              type="email"
              placeholder="Enter CC email for reports"
              value={ccEmail}
              onChange={(e) => setCcEmail(e.target.value)}
            />
          </div>

          <div className="flex items-center space-x-2">
            <Switch id="auto-send" checked={autoSendReports} onCheckedChange={setAutoSendReports} />
            <Label htmlFor="auto-send">Automatically send reports after analysis</Label>
          </div>

          <Button type="submit" disabled={isLoading}>
            {isLoading ? "Saving..." : "Save Settings"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
