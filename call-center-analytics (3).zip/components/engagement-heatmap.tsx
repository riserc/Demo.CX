"use client"

import { useEffect, useState } from "react"
import { createClientClient } from "@/lib/supabase/client"
import { isSafeId } from "@/lib/utils"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

type EngagementHeatmapProps = {
  callId: string
}

export default function EngagementHeatmap({ callId }: EngagementHeatmapProps) {
  const [heatmapData, setHeatmapData] = useState<any>({})
  const [isLoading, setIsLoading] = useState(true)
  const supabase = createClientClient()

  useEffect(() => {
    const fetchHeatmapData = async () => {
      try {
        // Validate the ID format
        if (!isSafeId(callId)) {
          // Generate mock data for invalid IDs
          const mockData = {
            customer_engagement: generateMockHeatmapData(),
            agent_performance: generateMockHeatmapData(),
          }
          setHeatmapData(mockData)
          setIsLoading(false)
          return
        }

        // Check if this is a demo call
        if (callId.startsWith("demo-")) {
          const demoCalls = JSON.parse(localStorage.getItem("demoCalls") || "[]")
          const demoCall = demoCalls.find((c: any) => c.id === callId)

          if (demoCall?.analysis_result?.heatmap_data) {
            setHeatmapData(demoCall.analysis_result.heatmap_data)
          } else {
            // Generate mock data if not available
            const mockData = {
              customer_engagement: generateMockHeatmapData(),
              agent_performance: generateMockHeatmapData(),
            }
            setHeatmapData(mockData)
          }
        } else {
          // Try to fetch from Supabase
          const { data: call, error } = await supabase.from("calls").select("analysis_result").eq("id", callId).single()

          if (error) throw error

          if (call?.analysis_result?.heatmap_data) {
            setHeatmapData(call.analysis_result.heatmap_data)
          } else {
            // Generate mock data if not available
            const mockData = {
              customer_engagement: generateMockHeatmapData(),
              agent_performance: generateMockHeatmapData(),
            }
            setHeatmapData(mockData)
          }
        }
      } catch (error) {
        console.error("Error fetching heatmap data:", error)
        // Generate mock data on error
        const mockData = {
          customer_engagement: generateMockHeatmapData(),
          agent_performance: generateMockHeatmapData(),
        }
        setHeatmapData(mockData)
      } finally {
        setIsLoading(false)
      }
    }

    fetchHeatmapData()
  }, [callId, supabase])

  const generateMockHeatmapData = () => {
    // Generate a 10x6 grid of data points
    const data = []
    const metrics = ["Engagement", "Interest", "Satisfaction", "Clarity", "Empathy", "Resolution"]

    for (let i = 0; i < 10; i++) {
      const timePoint = {}
      const timeLabel = `${Math.floor(i / 2)}:${((i % 2) * 30).toString().padStart(2, "0")}`
      timePoint["time"] = timeLabel

      metrics.forEach((metric) => {
        timePoint[metric] = Math.floor(Math.random() * 100)
      })

      data.push(timePoint)
    }

    return data
  }

  const renderHeatmap = (data) => {
    if (!data || data.length === 0) return null

    const metrics = Object.keys(data[0]).filter((key) => key !== "time")
    const timePoints = data.map((d) => d.time)

    return (
      <div className="overflow-x-auto">
        <div className="min-w-[600px]">
          <div className="grid grid-cols-[100px_1fr] gap-2">
            <div className=""></div>
            <div className="grid grid-cols-10 gap-1">
              {timePoints.map((time, i) => (
                <div key={i} className="text-xs text-center font-medium">
                  {time}
                </div>
              ))}
            </div>

            {metrics.map((metric, i) => (
              <div key={i} className="grid grid-cols-[100px_1fr] gap-2">
                <div className="text-sm font-medium">{metric}</div>
                <div className="grid grid-cols-10 gap-1">
                  {data.map((d, j) => {
                    const value = d[metric]
                    let bgColor

                    if (value >= 80) bgColor = "bg-green-500"
                    else if (value >= 60) bgColor = "bg-green-300"
                    else if (value >= 40) bgColor = "bg-yellow-300"
                    else if (value >= 20) bgColor = "bg-orange-300"
                    else bgColor = "bg-red-300"

                    return (
                      <div
                        key={j}
                        className={`h-8 ${bgColor} rounded flex items-center justify-center text-xs font-medium text-white`}
                        title={`${metric}: ${value}%`}
                      >
                        {value}
                      </div>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Engagement Heatmap</CardTitle>
          <CardDescription>Customer engagement and agent performance over time</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-80 w-full bg-gray-100 dark:bg-gray-800 animate-pulse rounded-md" />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Engagement Heatmap</CardTitle>
        <CardDescription>Customer engagement and agent performance over time</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="customer">
          <TabsList className="mb-4">
            <TabsTrigger value="customer">Customer Engagement</TabsTrigger>
            <TabsTrigger value="agent">Agent Performance</TabsTrigger>
          </TabsList>
          <TabsContent value="customer" className="mt-0">
            {renderHeatmap(heatmapData.customer_engagement)}
          </TabsContent>
          <TabsContent value="agent" className="mt-0">
            {renderHeatmap(heatmapData.agent_performance)}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
