"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { createClientClient } from "@/lib/supabase/client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { formatDistanceToNow } from "date-fns"
import { AlertCircle, Info } from "lucide-react"

type Call = {
  id: string
  file_name: string
  status: string
  created_at: string
  analysis_result: any
}

export default function RecentAnalytics() {
  const [calls, setCalls] = useState<Call[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [demoMode, setDemoMode] = useState(false)
  const supabase = createClientClient()

  useEffect(() => {
    const fetchCalls = async () => {
      try {
        setError(null)

        // For demo purposes, get calls from localStorage
        const demoCalls = JSON.parse(localStorage.getItem("demoCalls") || "[]")

        // Try to get calls from Supabase if available
        try {
          const { data, error } = await supabase
            .from("calls")
            .select("*")
            .order("created_at", { ascending: false })
            .limit(5)

          if (!error && data && data.length > 0) {
            setCalls(data)
            setDemoMode(false)
          } else {
            // Fall back to demo calls
            setCalls(demoCalls)
            setDemoMode(true)
          }
        } catch (dbError) {
          console.error("Database error:", dbError)
          // Fall back to demo calls
          setCalls(demoCalls)
          setDemoMode(true)
        }
      } catch (error: any) {
        console.error("Error fetching calls:", error)
        setError(error.message || "Failed to load recent calls")
      } finally {
        setIsLoading(false)
      }
    }

    fetchCalls()

    // Listen for localStorage changes (for demo purposes)
    const handleStorageChange = () => {
      const demoCalls = JSON.parse(localStorage.getItem("demoCalls") || "[]")
      if (demoMode) {
        setCalls(demoCalls)
      }
    }

    window.addEventListener("storage", handleStorageChange)

    // Custom event listener for our own dispatched events
    const handleCustomStorageChange = () => {
      const demoCalls = JSON.parse(localStorage.getItem("demoCalls") || "[]")
      if (demoMode) {
        setCalls(demoCalls)
      }
    }

    window.addEventListener("localStorageChange", handleCustomStorageChange)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("localStorageChange", handleCustomStorageChange)
    }
  }, [supabase, demoMode])

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Analytics</CardTitle>
          <CardDescription>Your most recent call analyses</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-16 bg-gray-100 dark:bg-gray-800 animate-pulse rounded-md" />
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Analytics</CardTitle>
        <CardDescription>Your most recent call analyses</CardDescription>
      </CardHeader>
      <CardContent>
        {demoMode && (
          <div className="flex items-center p-3 mb-4 text-sm border rounded-lg bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-800">
            <Info className="h-4 w-4 mr-2 flex-shrink-0" />
            Running in demo mode. Data is stored locally in your browser.
          </div>
        )}

        {error ? (
          <div className="flex items-center p-4 text-sm border rounded-lg bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-800">
            <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0" />
            <p>{error}</p>
          </div>
        ) : calls.length === 0 ? (
          <p className="text-center py-4 text-gray-500 dark:text-gray-400">
            No calls analyzed yet. Upload your first call recording to get started.
          </p>
        ) : (
          <div className="space-y-4">
            {calls.map((call) => (
              <Link
                key={call.id}
                href={`/dashboard/${call.id}`}
                className="block p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-medium">{call.file_name}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {formatDistanceToNow(new Date(call.created_at), { addSuffix: true })}
                    </p>
                  </div>
                  <Badge
                    variant={
                      call.status === "completed" ? "success" : call.status === "processing" ? "warning" : "destructive"
                    }
                  >
                    {call.status}
                  </Badge>
                </div>
                {call.status === "completed" && call.analysis_result && (
                  <div className="mt-2 grid grid-cols-3 gap-2 text-sm">
                    <div>
                      <p className="text-gray-500 dark:text-gray-400">Sentiment</p>
                      <p className="font-medium">{call.analysis_result.sentiment || "N/A"}</p>
                    </div>
                    <div>
                      <p className="text-gray-500 dark:text-gray-400">Duration</p>
                      <p className="font-medium">{call.analysis_result.duration || "N/A"}</p>
                    </div>
                    <div>
                      <p className="text-gray-500 dark:text-gray-400">Score</p>
                      <p className="font-medium">{call.analysis_result.agent_score || "N/A"}</p>
                    </div>
                  </div>
                )}
              </Link>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
