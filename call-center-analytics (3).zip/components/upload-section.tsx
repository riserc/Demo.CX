"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClientClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Upload, AlertCircle, Info } from "lucide-react"
import { analyzeAudio } from "@/lib/analyze-audio"
import { ensureStorageBucket } from "@/lib/ensure-bucket"
import { toast } from "@/components/ui/use-toast"

export default function UploadSection() {
  const [file, setFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const [bucketReady, setBucketReady] = useState(false)
  const [demoMode, setDemoMode] = useState(true) // Default to demo mode
  const router = useRouter()
  const supabase = createClientClient()

  const BUCKET_NAME = "call-recordings"

  useEffect(() => {
    // Check if we can access the storage bucket
    const checkBucketAccess = async () => {
      try {
        // First, try to set up the database tables
        await fetch("/api/setup-db")

        // Then check if we can access the bucket
        const ready = await ensureStorageBucket(BUCKET_NAME)
        setBucketReady(ready)
        setDemoMode(!ready) // If bucket is not ready, use demo mode

        if (!ready) {
          console.log("Storage bucket not accessible, using demo mode")
        }
      } catch (error) {
        console.error("Error checking bucket access:", error)
        setBucketReady(false)
        setDemoMode(true) // Use demo mode on error
      }
    }

    checkBucketAccess()
  }, [])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null)
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0]

      // Check file size (100MB max)
      if (selectedFile.size > 100 * 1024 * 1024) {
        setError("File size exceeds the 100MB limit")
        return
      }

      setFile(selectedFile)
    }
  }

  const handleReset = () => {
    setFile(null)
    setUploadProgress(0)
    setError(null)
  }

  // For demo purposes, let's simulate a working upload without actual storage
  const handleDemoUpload = async () => {
    if (!file) return

    try {
      setIsUploading(true)
      setError(null)

      // Simulate upload progress
      for (let i = 0; i <= 50; i += 10) {
        setUploadProgress(i)
        await new Promise((resolve) => setTimeout(resolve, 200))
      }

      // Simulate analysis
      setUploadProgress(60)
      const demoId = `demo-${Date.now()}`
      const analysisResult = await analyzeAudio(demoId, "demo-url")

      // Simulate completion
      for (let i = 70; i <= 100; i += 10) {
        setUploadProgress(i)
        await new Promise((resolve) => setTimeout(resolve, 200))
      }

      toast({
        title: "Demo Analysis Complete",
        description: "This is a demo analysis. In a real app, your call would be stored and analyzed.",
      })

      // Store demo data in localStorage for the demo
      const demoCall = {
        id: demoId,
        file_name: file.name,
        file_path: "demo-path",
        file_url: "demo-url",
        status: "completed",
        analysis_result: analysisResult,
        created_at: new Date().toISOString(),
      }

      // Store in localStorage for demo purposes
      const demoCalls = JSON.parse(localStorage.getItem("demoCalls") || "[]")
      demoCalls.unshift(demoCall)
      localStorage.setItem("demoCalls", JSON.stringify(demoCalls))

      // Trigger storage event to update other components
      window.dispatchEvent(new Event("storage"))

      // Redirect to dashboard
      router.push(`/dashboard/${demoId}`)
    } catch (error: any) {
      console.error("Demo upload failed:", error)
      setError(error.message || "An unexpected error occurred")
    } finally {
      setIsUploading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="h-5 w-5 text-teal-500" />
          Upload Call Recording
        </CardTitle>
        <CardDescription>Supercharge your Cx game with rich analysis and insights</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {demoMode && (
            <div className="flex items-center p-3 text-sm border rounded-lg bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-800">
              <Info className="h-4 w-4 mr-2 flex-shrink-0" />
              Running in demo mode. Files will be processed locally and stored in your browser.
            </div>
          )}

          <div className="flex items-center justify-center w-full">
            <label
              htmlFor="file-upload"
              className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 border-gray-300 dark:border-gray-600"
            >
              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                <Upload className="w-8 h-8 mb-3 text-gray-500 dark:text-gray-400" />
                <p className="mb-2 text-sm text-gray-500 dark:text-gray-400">
                  <span className="font-semibold">Click to upload</span> or drag and drop
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400">MP3, WAV, M4A, or OPUS (MAX. 100MB)</p>
              </div>
              <input
                id="file-upload"
                type="file"
                className="hidden"
                accept=".mp3,.wav,.m4a,.opus"
                onChange={handleFileChange}
                disabled={isUploading}
              />
            </label>
          </div>

          {error && (
            <div className="flex items-center p-3 text-sm border rounded-lg bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 border-red-200 dark:border-red-800">
              <AlertCircle className="h-4 w-4 mr-2 flex-shrink-0" />
              {error}
            </div>
          )}

          {file && (
            <div className="flex items-center justify-between p-2 border rounded-lg bg-gray-50 dark:bg-gray-800">
              <span className="text-sm truncate max-w-[200px]">{file.name}</span>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={handleReset} disabled={isUploading}>
                  Reset
                </Button>
                <Button size="sm" onClick={handleDemoUpload} disabled={isUploading}>
                  {isUploading ? `Processing ${uploadProgress}%` : "Analyze Call"}
                </Button>
              </div>
            </div>
          )}

          <div className="mt-4 text-xs text-center text-gray-500 dark:text-gray-400">
            <p>
              This is a demo application. Files are processed locally in your browser.
              <br />
              In a production environment, proper storage and security measures would be implemented.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
