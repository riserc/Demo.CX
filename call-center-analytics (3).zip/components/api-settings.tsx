"use client"

import { useState } from "react"
import { createClientClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"
import { Copy, RefreshCw } from "lucide-react"

export default function ApiSettings() {
  const [apiKey, setApiKey] = useState("••••••••••••••••")
  const [isLoading, setIsLoading] = useState(false)
  const [isRevealed, setIsRevealed] = useState(false)
  const supabase = createClientClient()

  // Load API key from database
  useState(() => {
    const fetchApiKey = async () => {
      try {
        const { data, error } = await supabase.from("settings").select("*").eq("type", "api").single()

        if (error && error.code !== "PGRST116") throw error

        if (data && isRevealed) {
          setApiKey(data.settings.api_key || "")
        }
      } catch (error) {
        console.error("Error fetching API key:", error)
      }
    }

    fetchApiKey()
  })

  const handleRevealApiKey = async () => {
    try {
      setIsLoading(true)

      const { data, error } = await supabase.from("settings").select("*").eq("type", "api").single()

      if (error && error.code !== "PGRST116") throw error

      if (data) {
        setApiKey(data.settings.api_key || "")
      }

      setIsRevealed(true)
    } catch (error) {
      console.error("Error revealing API key:", error)
      toast({
        title: "Error",
        description: "There was an error revealing the API key.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleRegenerateApiKey = async () => {
    try {
      setIsLoading(true)

      // Generate a new API key
      const newApiKey = Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join("")

      // Save the new API key
      const { error } = await supabase.from("settings").upsert({
        type: "api",
        settings: {
          api_key: newApiKey,
        },
      })

      if (error) throw error

      setApiKey(newApiKey)
      setIsRevealed(true)

      toast({
        title: "API Key Regenerated",
        description: "Your API key has been regenerated successfully.",
      })
    } catch (error) {
      console.error("Error regenerating API key:", error)
      toast({
        title: "Regeneration Failed",
        description: "There was an error regenerating the API key.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleCopyApiKey = () => {
    navigator.clipboard.writeText(apiKey)
    toast({
      title: "API Key Copied",
      description: "The API key has been copied to your clipboard.",
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>API Settings</CardTitle>
        <CardDescription>Manage your API key for integrations</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="api-key">API Key</Label>
          <div className="flex">
            <Input id="api-key" type="text" value={apiKey} readOnly className="font-mono" />
            <Button variant="outline" size="icon" onClick={handleCopyApiKey} className="ml-2" disabled={!isRevealed}>
              <Copy className="h-4 w-4" />
              <span className="sr-only">Copy API key</span>
            </Button>
          </div>
        </div>

        <div className="flex gap-2">
          {!isRevealed ? (
            <Button onClick={handleRevealApiKey} disabled={isLoading}>
              {isLoading ? "Loading..." : "Reveal API Key"}
            </Button>
          ) : (
            <Button onClick={handleRegenerateApiKey} disabled={isLoading}>
              <RefreshCw className="h-4 w-4 mr-2" />
              {isLoading ? "Regenerating..." : "Regenerate API Key"}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
