"use client"

import { useEffect, useState } from "react"
import { createClientClient } from "@/lib/supabase/client"
import { isSafeId } from "@/lib/utils"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle, Clock, ThumbsDown, ThumbsUp } from "lucide-react"

type KeyInsightsProps = {
  callId: string
}

export default function KeyInsights({ callId }: KeyInsightsProps) {
  const [insights, setInsights] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const supabase = createClientClient()

  useEffect(() => {
    const fetchInsights = async () => {
      try {
        // Validate the ID format
        if (!isSafeId(callId)) {
          // Generate mock data for invalid IDs
          const mockData = generateMockData()
          setInsights(mockData)
          setIsLoading(false)
          return
        }

        // Check if this is a demo call
        if (callId.startsWith("demo-")) {
          const demoCalls = JSON.parse(localStorage.getItem("demoCalls") || "[]")
          const demoCall = demoCalls.find((c: any) => c.id === callId)

          if (demoCall?.analysis_result?.insights) {
            setInsights(demoCall.analysis_result.insights)
          } else {
            // Generate mock data if not available
            const mockData = generateMockData()
            setInsights(mockData)
          }
        } else {
          // Try to fetch from Supabase
          const { data: call, error } = await supabase.from("calls").select("analysis_result").eq("id", callId).single()

          if (error) throw error

          if (call?.analysis_result?.insights) {
            setInsights(call.analysis_result.insights)
          } else {
            // Generate mock data if not available
            const mockData = generateMockData()
            setInsights(mockData)
          }
        }
      } catch (error) {
        console.error("Error fetching insights:", error)
        // Generate mock data on error
        const mockData = generateMockData()
        setInsights(mockData)
      } finally {
        setIsLoading(false)
      }
    }

    fetchInsights()
  }, [callId, supabase])

  const generateMockData = () => {
    return [
      {
        type: "positive",
        text: "Agent showed excellent empathy when customer expressed frustration",
      },
      {
        type: "negative",
        text: "Long periods of silence during troubleshooting steps",
      },
      {
        type: "warning",
        text: "Agent could have offered additional product information",
      },
      {
        type: "info",
        text: "Customer mentioned interest in premium subscription",
      },
      {
        type: "positive",
        text: "Issue was resolved within the first 5 minutes of the call",
      },
    ]
  }

  const getIcon = (type: string) => {
    switch (type) {
      case "positive":
        return <ThumbsUp className="h-5 w-5 text-green-500" />
      case "negative":
        return <ThumbsDown className="h-5 w-5 text-red-500" />
      case "warning":
        return <AlertTriangle className="h-5 w-5 text-amber-500" />
      case "info":
      default:
        return <Clock className="h-5 w-5 text-blue-500" />
    }
  }

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Key Insights</CardTitle>
          <CardDescription>Important observations from the call</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-12 bg-gray-100 dark:bg-gray-800 animate-pulse rounded-md" />
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Key Insights</CardTitle>
        <CardDescription>Important observations from the call</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {insights.map((insight, index) => (
            <div key={index} className="flex items-start gap-3 p-2 rounded-lg bg-gray-50 dark:bg-gray-800">
              <div className="mt-0.5">{getIcon(insight.type)}</div>
              <p className="text-sm">{insight.text}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
