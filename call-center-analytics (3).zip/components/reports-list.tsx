import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { formatDistanceToNow } from "date-fns"
import { Download, ExternalLink } from "lucide-react"

type Report = {
  id: string
  call_id: string
  email: string
  pdf_url: string
  status: string
  created_at: string
}

type ReportsListProps = {
  reports: Report[]
}

export default function ReportsList({ reports }: ReportsListProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Generated Reports</CardTitle>
        <CardDescription>Reports you've generated and shared</CardDescription>
      </CardHeader>
      <CardContent>
        {reports.length === 0 ? (
          <p className="text-center py-4 text-gray-500 dark:text-gray-400">
            No reports generated yet. Generate your first report to get started.
          </p>
        ) : (
          <div className="space-y-4">
            {reports.map((report) => (
              <div
                key={report.id}
                className="p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-medium">Report #{report.id.slice(0, 8)}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Sent to: {report.email}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {formatDistanceToNow(new Date(report.created_at), { addSuffix: true })}
                    </p>
                  </div>
                  <Badge
                    variant={
                      report.status === "sent" ? "success" : report.status === "pending" ? "warning" : "destructive"
                    }
                  >
                    {report.status}
                  </Badge>
                </div>
                <div className="mt-2 flex gap-2">
                  <Button variant="outline" size="sm" asChild>
                    <a href={report.pdf_url} download>
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </a>
                  </Button>
                  <Button variant="outline" size="sm" asChild>
                    <Link href={`/dashboard/${report.call_id}`}>
                      <ExternalLink className="h-4 w-4 mr-2" />
                      View Call
                    </Link>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
