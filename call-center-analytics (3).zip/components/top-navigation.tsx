"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { BarChart2, FileText, Home, Settings } from "lucide-react"

const navigation = [
  { name: "Home", href: "/", icon: Home },
  { name: "Dashboard", href: "/dashboard", icon: BarChart2 },
  { name: "Reports", href: "/reports", icon: FileText },
  { name: "Settings", href: "/settings", icon: Settings },
]

export default function TopNavigation() {
  const pathname = usePathname()

  return (
    <div className="flex items-center space-x-1 overflow-x-auto pb-2">
      {navigation.map((item) => (
        <Link
          key={item.name}
          href={item.href}
          className={cn(
            pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href))
              ? "bg-teal-50 text-teal-600 dark:bg-teal-900/50 dark:text-teal-400"
              : "text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-800",
            "group flex items-center px-3 py-2 text-sm font-medium rounded-md whitespace-nowrap",
          )}
        >
          <item.icon
            className={cn(
              pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href))
                ? "text-teal-500 dark:text-teal-400"
                : "text-gray-400 group-hover:text-gray-500 dark:text-gray-400 dark:group-hover:text-gray-300",
              "mr-3 flex-shrink-0 h-5 w-5",
            )}
            aria-hidden="true"
          />
          {item.name}
        </Link>
      ))}
    </div>
  )
}
