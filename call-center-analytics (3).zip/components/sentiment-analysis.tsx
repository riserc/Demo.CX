"use client"

import { useEffect, useState } from "react"
import { createClientClient } from "@/lib/supabase/client"
import { isSafeId } from "@/lib/utils"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

type SentimentAnalysisProps = {
  callId: string
}

export default function SentimentAnalysis({ callId }: SentimentAnalysisProps) {
  const [sentimentData, setSentimentData] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const supabase = createClientClient()

  useEffect(() => {
    const fetchSentimentData = async () => {
      try {
        // Validate the ID format
        if (!isSafeId(callId)) {
          // Generate mock data for invalid IDs
          const mockData = generateMockData()
          setSentimentData(mockData)
          setIsLoading(false)
          return
        }

        // Check if this is a demo call
        if (callId.startsWith("demo-")) {
          const demoCalls = JSON.parse(localStorage.getItem("demoCalls") || "[]")
          const demoCall = demoCalls.find((c: any) => c.id === callId)

          if (demoCall?.analysis_result?.sentiment_timeline) {
            setSentimentData(demoCall.analysis_result.sentiment_timeline)
          } else {
            // Generate mock data if not available
            const mockData = generateMockData()
            setSentimentData(mockData)
          }
        } else {
          // Try to fetch from Supabase
          const { data: call, error } = await supabase.from("calls").select("analysis_result").eq("id", callId).single()

          if (error) throw error

          if (call?.analysis_result?.sentiment_timeline) {
            setSentimentData(call.analysis_result.sentiment_timeline)
          } else {
            // Generate mock data if not available
            const mockData = generateMockData()
            setSentimentData(mockData)
          }
        }
      } catch (error) {
        console.error("Error fetching sentiment data:", error)
        // Generate mock data on error
        const mockData = generateMockData()
        setSentimentData(mockData)
      } finally {
        setIsLoading(false)
      }
    }

    fetchSentimentData()
  }, [callId, supabase])

  const generateMockData = () => {
    return Array.from({ length: 20 }, (_, i) => ({
      time: `${Math.floor(i / 60)}:${(i % 60).toString().padStart(2, "0")}`,
      agent: Math.random() * 2 - 1,
      customer: Math.random() * 2 - 1,
    }))
  }

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Sentiment Analysis</CardTitle>
          <CardDescription>Sentiment trends throughout the call</CardDescription>
        </CardHeader>
        <CardContent className="h-80">
          <div className="h-full w-full bg-gray-100 dark:bg-gray-800 animate-pulse rounded-md" />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sentiment Analysis</CardTitle>
        <CardDescription>Sentiment trends throughout the call</CardDescription>
      </CardHeader>
      <CardContent className="h-80">
        <ChartContainer
          config={{
            agent: {
              label: "Agent Sentiment",
              color: "hsl(var(--chart-1))",
            },
            customer: {
              label: "Customer Sentiment",
              color: "hsl(var(--chart-2))",
            },
          }}
          className="h-full"
        >
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={sentimentData} margin={{ top: 5, right: 10, left: 10, bottom: 5 }}>
              <XAxis dataKey="time" />
              <YAxis
                domain={[-1, 1]}
                ticks={[-1, -0.5, 0, 0.5, 1]}
                tickFormatter={(value) => {
                  if (value === -1) return "Negative"
                  if (value === 0) return "Neutral"
                  if (value === 1) return "Positive"
                  return ""
                }}
              />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Line type="monotone" dataKey="agent" stroke="var(--color-agent)" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="customer" stroke="var(--color-customer)" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
