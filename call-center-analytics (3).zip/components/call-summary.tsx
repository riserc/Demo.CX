import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { formatDistanceToNow } from "date-fns"

type CallSummaryProps = {
  call: {
    id: string
    file_name: string
    status: string
    created_at: string
    analysis_result: any
  }
}

export default function CallSummary({ call }: CallSummaryProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Call Summary</CardTitle>
        <CardDescription>Overview of the analyzed call</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">File Name</h3>
              <p className="mt-1">{call.file_name}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Status</h3>
              <Badge
                className="mt-1"
                variant={
                  call.status === "completed" ? "success" : call.status === "processing" ? "warning" : "destructive"
                }
              >
                {call.status}
              </Badge>
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Uploaded</h3>
              <p className="mt-1">{formatDistanceToNow(new Date(call.created_at), { addSuffix: true })}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Duration</h3>
              <p className="mt-1">{call.analysis_result?.duration || "N/A"}</p>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Summary</h3>
            <p className="mt-1 text-sm">{call.analysis_result?.summary || "Summary not available"}</p>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">Sentiment</h3>
              <p className="mt-1 text-2xl font-bold text-green-600 dark:text-green-400">
                {call.analysis_result?.sentiment || "N/A"}
              </p>
            </div>
            <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">Agent Score</h3>
              <p className="mt-1 text-2xl font-bold text-blue-600 dark:text-blue-400">
                {call.analysis_result?.agent_score || "N/A"}
              </p>
            </div>
            <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
              <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">Customer Score</h3>
              <p className="mt-1 text-2xl font-bold text-purple-600 dark:text-purple-400">
                {call.analysis_result?.customer_score || "N/A"}
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
