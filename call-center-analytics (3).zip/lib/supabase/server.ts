import { createServerClient as createClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import type { Database } from "../types/database"

export function createServerClient() {
  const cookieStore = cookies()

  // Use the provided service role key for server operations
  return createClient<Database>(
    "https://kzdfnpvfyjsszhfzniqf.supabase.co",
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt6ZGZucHZmeWpzc3poZnpuaXFmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU5OTc1OTgsImV4cCI6MjA2MTU3MzU5OH0.3FXISx4ONbM5xPT9b_62cfFWMot1uF9zHGjCPOmgTIQ",
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value
        },
      },
    },
  )
}
