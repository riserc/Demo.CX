import { createBrowserClient } from "@supabase/ssr"
import type { Database } from "../types/database"

// Singleton instance
let supabaseClient: ReturnType<typeof createBrowserClient<Database>> | null = null

export function createClientClient() {
  if (supabaseClient) {
    return supabaseClient
  }

  // Use the provided anon key
  supabaseClient = createBrowserClient<Database>(
    "https://kzdfnpvfyjsszhfzniqf.supabase.co",
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt6ZGZucHZmeWpzc3poZnpuaXFmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU5OTc1OTgsImV4cCI6MjA2MTU3MzU5OH0.3FXISx4ONbM5xPT9b_62cfFWMot1uF9zHGjCPOmgTIQ",
  )

  return supabaseClient
}
