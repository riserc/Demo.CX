import { createClientClient } from "./supabase/client"

export async function ensureStorageBucket(bucketName: string): Promise<boolean> {
  const supabase = createClientClient()

  try {
    // Instead of trying to create the bucket (which requires admin privileges),
    // we'll check if we can access it and assume it exists
    const { data: files, error } = await supabase.storage.from(bucketName).list("", { limit: 1 })

    if (error) {
      // If the error is about the bucket not existing, we can't create it from the client
      console.error(`Storage bucket ${bucketName} is not accessible:`, error)
      return false
    }

    // If we can list files, the bucket exists and we have access
    return true
  } catch (error) {
    console.error(`Error ensuring storage bucket ${bucketName}:`, error)
    return false
  }
}
