"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"

export function useAuthCheck() {
  const router = useRouter()

  useEffect(() => {
    // Check if authenticated in localStorage
    const isAuthenticated = localStorage.getItem("isAuthenticated") === "true"

    if (!isAuthenticated) {
      // If not authenticated, redirect to login
      router.push("/login")
    }
  }, [router])

  return { isAuthenticated: typeof window !== "undefined" ? localStorage.getItem("isAuthenticated") === "true" : false }
}

export function setAuthenticated(email = "demo@example.com") {
  localStorage.setItem("isAuthenticated", "true")
  localStorage.setItem("user", JSON.stringify({ email }))
}

export function clearAuthentication() {
  localStorage.removeItem("isAuthenticated")
  localStorage.removeItem("user")
}
