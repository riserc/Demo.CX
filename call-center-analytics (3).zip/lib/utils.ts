import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// UUID validation regex
const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i

export function isValidUUID(id: string): boolean {
  return UUID_REGEX.test(id)
}

// Safe ID handling for demo and real IDs
export function isSafeId(id: string): boolean {
  // Allow demo IDs that follow our pattern
  if (id.startsWith("demo-") && !isNaN(Number(id.substring(5)))) {
    return true
  }

  // Or valid UUIDs
  return isValidUUID(id)
}
