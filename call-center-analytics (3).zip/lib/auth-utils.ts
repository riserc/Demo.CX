"use client"

/**
 * Sets the user as authenticated in localStorage
 */
export function setAuthenticated(email = "demo@example.com") {
  try {
    localStorage.setItem("isAuthenticated", "true")
    localStorage.setItem("user", JSON.stringify({ email }))
    return true
  } catch (error) {
    console.error("Error setting authentication:", error)
    return false
  }
}

/**
 * Clears authentication data from localStorage
 */
export function clearAuthentication() {
  try {
    localStorage.removeItem("isAuthenticated")
    localStorage.removeItem("user")
    return true
  } catch (error) {
    console.error("Error clearing authentication:", error)
    return false
  }
}

/**
 * Checks if the user is authenticated
 */
export function isAuthenticated() {
  try {
    return localStorage.getItem("isAuthenticated") === "true"
  } catch (error) {
    console.error("Error checking authentication:", error)
    return false
  }
}

/**
 * Gets the authenticated user's email
 */
export function getUserEmail() {
  try {
    const userStr = localStorage.getItem("user")
    if (userStr) {
      const user = JSON.parse(userStr)
      return user.email || "demo@example.com"
    }
    return "demo@example.com"
  } catch (error) {
    console.error("Error getting user email:", error)
    return "demo@example.com"
  }
}
