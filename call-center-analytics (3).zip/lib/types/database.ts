export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      calls: {
        Row: {
          id: string
          file_name: string
          file_path: string
          file_url: string
          status: string
          analysis_result: Json | null
          created_at: string
        }
        Insert: {
          id?: string
          file_name: string
          file_path: string
          file_url: string
          status: string
          analysis_result?: Json | null
          created_at?: string
        }
        Update: {
          id?: string
          file_name?: string
          file_path?: string
          file_url?: string
          status?: string
          analysis_result?: Json | null
          created_at?: string
        }
      }
      reports: {
        Row: {
          id: string
          call_id: string
          email: string | null
          pdf_url: string
          status: string
          created_at: string
        }
        Insert: {
          id?: string
          call_id: string
          email?: string | null
          pdf_url: string
          status: string
          created_at?: string
        }
        Update: {
          id?: string
          call_id?: string
          email?: string | null
          pdf_url?: string
          status?: string
          created_at?: string
        }
      }
      settings: {
        Row: {
          id: string
          type: string
          settings: Json
          created_at: string
        }
        Insert: {
          id?: string
          type: string
          settings: Json
          created_at?: string
        }
        Update: {
          id?: string
          type?: string
          settings?: Json
          created_at?: string
        }
      }
    }
  }
}
