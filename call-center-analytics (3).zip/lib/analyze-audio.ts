// This is a mock implementation for demo purposes
// In a real application, you would integrate with an AI service for audio analysis

export async function analyzeAudio(callId: string, audioUrl: string): Promise<any> {
  // Simulate processing time
  await new Promise((resolve) => setTimeout(resolve, 2000))

  // Generate mock analysis results
  const sentimentOptions = ["Positive", "Neutral", "Negative", "Mixed"]
  const randomSentiment = sentimentOptions[Math.floor(Math.random() * sentimentOptions.length)]

  const durationMinutes = Math.floor(Math.random() * 10) + 1
  const durationSeconds = Math.floor(Math.random() * 60)
  const duration = `${durationMinutes}:${durationSeconds.toString().padStart(2, "0")}`

  const agentScore = Math.floor(Math.random() * 41) + 60 // 60-100
  const customerScore = Math.floor(Math.random() * 41) + 60 // 60-100

  // Generate sentiment timeline
  const sentimentTimeline = Array.from({ length: 20 }, (_, i) => ({
    time: `${Math.floor(i / 60)}:${(i % 60).toString().padStart(2, "0")}`,
    agent: Math.random() * 2 - 1, // -1 to 1
    customer: Math.random() * 2 - 1, // -1 to 1
  }))

  // Generate agent metrics
  const agentMetrics = [
    { metric: "Empathy", score: Math.floor(Math.random() * 41) + 60 },
    { metric: "Clarity", score: Math.floor(Math.random() * 41) + 60 },
    { metric: "Resolution", score: Math.floor(Math.random() * 41) + 60 },
    { metric: "Knowledge", score: Math.floor(Math.random() * 41) + 60 },
    { metric: "Professionalism", score: Math.floor(Math.random() * 41) + 60 },
  ]

  // Generate insights
  const insightTypes = ["positive", "negative", "warning", "info"]
  const insightTexts = [
    "Agent showed excellent empathy when customer expressed frustration",
    "Long periods of silence during troubleshooting steps",
    "Agent could have offered additional product information",
    "Customer mentioned interest in premium subscription",
    "Issue was resolved within the first 5 minutes of the call",
    "Agent used technical jargon that confused the customer",
    "Customer had to repeat information multiple times",
    "Agent provided clear step-by-step instructions",
    "Customer expressed satisfaction with the resolution",
    "Agent followed up with additional resources via email",
  ]

  const insights = Array.from({ length: 5 }, () => ({
    type: insightTypes[Math.floor(Math.random() * insightTypes.length)],
    text: insightTexts[Math.floor(Math.random() * insightTexts.length)],
  }))

  // Generate transcript
  const transcript = [
    {
      speaker: "agent" as const,
      text: "Thank you for calling customer support. How may I help you today?",
      time: "00:00",
    },
    {
      speaker: "customer" as const,
      text: "Hi, I'm having trouble with my account. I can't seem to log in.",
      time: "00:05",
    },
    {
      speaker: "agent" as const,
      text: "I'm sorry to hear that. Let me help you with that. Can you please provide your account email?",
      time: "00:12",
    },
    {
      speaker: "customer" as const,
      text: "Sure, it's customer@example.com",
      time: "00:18",
    },
    {
      speaker: "agent" as const,
      text: "Thank you. I'm checking your account now. It looks like there might have been some suspicious activity and your account was temporarily locked for security reasons.",
      time: "00:25",
    },
    {
      speaker: "customer" as const,
      text: "Oh, I see. How can I unlock it?",
      time: "00:40",
    },
    {
      speaker: "agent" as const,
      text: "I can help you with that right now. I'll send a password reset link to your email. Once you reset your password, your account will be unlocked.",
      time: "00:45",
    },
    {
      speaker: "customer" as const,
      text: "That sounds good. Thank you.",
      time: "01:00",
    },
    {
      speaker: "agent" as const,
      text: "You're welcome. Is there anything else I can help you with today?",
      time: "01:05",
    },
    {
      speaker: "customer" as const,
      text: "No, that's all. Thanks for your help.",
      time: "01:10",
    },
    {
      speaker: "agent" as const,
      text: "You're welcome. Thank you for calling customer support. Have a great day!",
      time: "01:15",
    },
  ]

  // Generate heatmap data
  const generateHeatmapData = () => {
    // Generate a 10x6 grid of data points
    const data = []
    const metrics = ["Engagement", "Interest", "Satisfaction", "Clarity", "Empathy", "Resolution"]

    for (let i = 0; i < 10; i++) {
      const timePoint = {}
      const timeLabel = `${Math.floor(i / 2)}:${((i % 2) * 30).toString().padStart(2, "0")}`
      timePoint["time"] = timeLabel

      metrics.forEach((metric) => {
        timePoint[metric] = Math.floor(Math.random() * 100)
      })

      data.push(timePoint)
    }

    return data
  }

  const heatmap_data = {
    customer_engagement: generateHeatmapData(),
    agent_performance: generateHeatmapData(),
  }

  return {
    sentiment: randomSentiment,
    duration,
    agent_score: agentScore,
    customer_score: customerScore,
    summary:
      "Customer called regarding login issues. Agent identified that the account was temporarily locked due to suspicious activity. Agent assisted by sending a password reset link to the customer's email. The issue was resolved successfully.",
    sentiment_timeline: sentimentTimeline,
    agent_metrics: agentMetrics,
    insights,
    transcript,
    heatmap_data,
  }
}
