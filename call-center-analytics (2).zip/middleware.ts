import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  // Skip middleware for API routes and static assets
  if (
    request.nextUrl.pathname.startsWith("/api/") ||
    request.nextUrl.pathname.startsWith("/_next/") ||
    request.nextUrl.pathname.includes(".")
  ) {
    return NextResponse.next()
  }

  // Check if the user is authenticated from cookies
  const isAuthenticated = request.cookies.get("isAuthenticated")?.value === "true"

  // For client-side authentication, we'll let the login page handle the check
  if (!isAuthenticated && !request.nextUrl.pathname.startsWith("/login")) {
    // Redirect to login
    return NextResponse.redirect(new URL("/login", request.url))
  }

  // If the user is authenticated and trying to access the login page
  if (isAuthenticated && request.nextUrl.pathname.startsWith("/login")) {
    return NextResponse.redirect(new URL("/", request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico).*)"],
}
