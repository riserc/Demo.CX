"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"
import { Upload } from "lucide-react"

export default function LoginPage() {
  const router = useRouter()

  // Auto-login effect
  useEffect(() => {
    const autoLogin = async () => {
      try {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 800))

        // Store auth state in localStorage
        localStorage.setItem("isAuthenticated", "true")
        localStorage.setItem("user", JSON.stringify({ email: "demo@example.com" }))

        toast({
          title: "Login successful",
          description: "Welcome to Vaaɹi.Cx Call Analytics",
        })

        // Redirect to dashboard
        router.push("/")
      } catch (error) {
        console.error("Auto-login failed:", error)
      }
    }

    // Check if already authenticated
    const isAuthenticated = localStorage.getItem("isAuthenticated") === "true"
    if (!isAuthenticated) {
      autoLogin()
    }
  }, [router])

  const handleDemoLogin = async () => {
    try {
      // Store auth state in localStorage
      localStorage.setItem("isAuthenticated", "true")
      localStorage.setItem("user", JSON.stringify({ email: "demo@example.com" }))

      toast({
        title: "Login successful",
        description: "Welcome to Vaaɹi.Cx Call Analytics",
      })

      // Redirect to dashboard
      router.push("/")
    } catch (error) {
      console.error("Login failed:", error)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-100 dark:bg-gray-900 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-center mb-2">
            <Upload className="h-10 w-10 text-teal-500" />
          </div>
          <CardTitle className="text-2xl font-bold">Vaaɹi.Cx</CardTitle>
          <CardDescription>Demo Call Analytics Platform</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center">
          <p className="mb-6 text-center text-sm text-gray-600 dark:text-gray-400">
            This is a demo application. Click the button below to enter.
          </p>
          <Button onClick={handleDemoLogin} className="w-full max-w-xs">
            Enter Demo
          </Button>
        </CardContent>
        <CardFooter className="flex justify-center">
          <p className="text-sm text-gray-500 dark:text-gray-400">No password required - automatic authentication</p>
        </CardFooter>
      </Card>
    </div>
  )
}
